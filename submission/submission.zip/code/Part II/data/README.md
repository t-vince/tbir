We provide two files:

1. target_collection
2. queries_val

The target_collection file contains of 17,784 documents (one for each line). Each line contains the following fields:
sentence id, image id, text caption

The queries_val file contains 1000 queries, using the same fields as above.

17784 target documents  (target_collection)
1000 queries for validation (queries_val)

In both files, each line represents a textual description corresponding to a particular image.  
